alert("Successfully Started Giga Hack X")
alert("scroll down to see buttons.")

//buttons\\
const button1 = document.createElement('button');
button1.innerText = 'Minute Farmer';
button1.id = "button1"

const lesson = document.createElement('button');
lesson.innerText = 'Enter Lesson';

// define the async function
async function handleClick() {
    let clickLesson = await page.$x("/html/body/div[1]/div[1]/section/div/div[2]/main/div/div/div/div/div/div/div/div")
    await clickLesson[0].click({ waitUntil: 'networkidle0'})
}

lesson.addEventListener('click', handleClick);
document.body.appendChild(lesson);

button1.addEventListener('click', () => {
    function pressAKey() {
        const event = new KeyboardEvent('keydown', { keyCode: 65 });
        document.dispatchEvent(event);
    }
  setInterval(pressAKey, 60000);
})
document.body.appendChild(button1);

const buttonState = localStorage.getItem('buttonState');
if (buttonState) {
 button1.style.display = buttonState;
}

window.addEventListener('beforeunload', () => {
    localStorage.setItem('buttonState', button1.style.display);
});

