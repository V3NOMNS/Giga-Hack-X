alert("Successfully Started Giga Hack X")
alert("scroll down to see buttons.")

//buttons\\
const button1 = document.createElement('button');
button1.innerText = 'Minute Farmer';
button1.id = "button1"

button1.addEventListener('click', () => {
    for (let i = 0; i < repeatCount; i++) {
        const event = new KeyboardEvent('keydown', { key: 'a' });
        document.dispatchEvent(event);
    }

    button1.disabled = true;

    let count = 0;
    function incrementCount() {
      count + 1;
      button1.innerText = count
    }
    setInterval(incrementCount, 60000); // 60000 milliseconds = 1 minute
  });

  let clickLesson = await page.$x("/html/body/div[1]/div[1]/section/div/div[2]/main/div/div/div/div/div/div/div/div")
  await clickLesson[0].click({ waitUntil: 'networkidle0'})

document.body.appendChild(button1);

const buttonState = localStorage.getItem('buttonState');
if (buttonState) {
 button1.style.display = buttonState;
}

window.addEventListener('beforeunload', () => {
    localStorage.setItem('buttonState', button1.style.display);
});

    

document.body.appendChild(button1);
